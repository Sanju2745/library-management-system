<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy;  Library Management System</a></strong>
</footer>